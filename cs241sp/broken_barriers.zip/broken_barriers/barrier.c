/**
 * Parallelized Poisson Problems
 * CS 241 - Spring 2016
 */
#include "barrier.h"

// The returns are just for errors if you want to check for them.
int barrier_destroy(barrier_t *t) {
  int error = 0;
  return error;
}

int barrier_init(barrier_t *t, unsigned n) {
  int error = 0;
  return error;
}

int barrier_wait(barrier_t *t) { return 0; }
