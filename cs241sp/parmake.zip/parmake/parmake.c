/**
 * Parallel Make
 * CS 241 - Spring 2016
 */

#include "parmake.h"
// Treat this as main
int parmake(int argc, char **argv) {
  // good luck!
  return 0;
}
