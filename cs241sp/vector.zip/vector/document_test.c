/**
 * Machine Problem 1
 * CS 241 - Spring 2016
 */

#include "document.h"
// test your document here
int main() { return 0; }
