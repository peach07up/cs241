/**
 * Machine Problem 1
 * CS 241 - Spring 2016
 */

#include "vector.h"

// Test your vector here
int main() { return 0; }
