echo "Checking _received.rp and _expected.rp"
diff _received.rp _expected.rp
echo "Done."
