/**
 * Chatroom Lab
 * CS 241 - Spring 2016
 */
void *run_client(void *arg);
void close_client();