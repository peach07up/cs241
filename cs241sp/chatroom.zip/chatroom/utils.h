/**
 * Chatroom Lab
 * CS 241 - Spring 2016
 */
// Function that reads user input and writes it to server
void *write_to_server(void *arg);

// Function that reads bytes from the server and prints it
// to the user's screen
void *read_from_server();
