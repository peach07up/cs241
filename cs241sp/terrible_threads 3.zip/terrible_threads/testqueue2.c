//#include "queue.h"
#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


void Queue_test()
{
    queue_t testQueue;
    queue_init(&testQueue, 200);
    
    int a = 34;
    int b = 35;
    int c = 36;
    int d = 37;
    int e = 38;
    
    queue_push( &testQueue, &a );
    queue_push( &testQueue, &b );
    queue_push( &testQueue, &c );
    
    queue_push( &testQueue, &d );
    queue_push( &testQueue, &e );
    queue_push( &testQueue, &e );
    
    queue_pull( &testQueue);
    queue_pull( &testQueue);
    queue_pull( &testQueue);
    queue_pull( &testQueue);
 
    
    queue_pull( &testQueue);


    queue_push( &testQueue, &a );
    queue_push( &testQueue, &b );
    queue_push( &testQueue, &c );
    
    queue_destroy(&testQueue);
}