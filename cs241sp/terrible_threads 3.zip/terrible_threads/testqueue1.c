#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#include "queue.h"

#define NUM_THREADS 20
#define NUM_INSERTS 50

void * thread_insert(void * arg);

int main(void)
{
    int i;
    queue_t q;
    queue_init(&q,NUM_THREADS*NUM_INSERTS*2);
    pthread_t * insert_threads = malloc(NUM_THREADS*sizeof(pthread_t));
    
    for (i=0; i<NUM_THREADS; i++)
    {
        pthread_create(&insert_threads[i], NULL, thread_insert, &q);
        
    }
    
    void * out;
    
    for (i=0; i<NUM_THREADS; i++)
    {
        pthread_join(insert_threads[i], &out);
    }
    
    long k = 0;
    
    
    k += (long) queue_pull(&q);

    
    queue_destroy(&q);
    if (k == NUM_INSERTS*NUM_THREADS)
        printf("Success! Data inserted and removed.\n");
    else
        printf("Failed to retrieve all inserted data!\n");
    return 0;
}


void * thread_insert(void * arg)
{
    int i;
    queue_t * q = (queue_t *) arg;
    for (i = 0; i < NUM_INSERTS; i++)
        queue_push(q, (void *) 1);
    return NULL;
    
}

