/**
 * MapReduce
 * CS 241 - Spring 2016
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "common.h"

int main(int argc, char **argv) {
  // setup pipes
  // start mappers
  // start shuffler
  // start reducers
  // wait for everything to finish
}
