/**
 * MapReduce
 * CS 241 - Spring 2016
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>
#include "common.h"

void usage() {
  printf("./mr1 input_file output_file mapper_exec reducer_exec num_mappers\n");
}

int main(int argc, char **argv) {
  // Create an input pipe for each mapper.

  // Create one input pipe for the reducer.

  // Open the output file.

  // Start a splitter process for each mapper.

  // Start all the mapper processes.

  // Start the reducer process.

  // Wait for the reducer to finish.

  // Print nonzero subprocess exit codes.

  // Count the number of lines in the output file.

  return 0;
}
