/**
 * Machine Problem: Password Cracker
 * CS 241 - Spring 2016
 */

#include "cracker2.h"

int start(size_t thread_count) {
  // TODO your code here, make sure to use thread_count!
  return 0;
}
