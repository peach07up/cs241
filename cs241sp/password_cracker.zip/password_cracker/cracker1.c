/**
 * Machine Problem: Password Cracker
 * CS 241 - Spring 2016
 */

#include "cracker1.h"

int start(size_t thread_count) {
  // your code here
  // make sure to make thread_count threads
  return 0;
}
