/**
 * Et Tu, Brute Lab
 * CS 241 - Spring 2016
 */
/**
 * Return the most likely shift of 'line'.
 *
 * Note: 'most likely' means closet to the English language by character
 *frequencies.
 * Note: It is up to the caller to free the string returned.
 */
char *get_most_likely_print_out(char *line);
