/**
 * Ideal Indirection Lab
 * CS 241 - Spring 2016
 */
#ifndef __KERNEL_H__
#define __KERNEL_H__

#include <stdlib.h>

void *ask_kernel_for_frame();

#endif /* __KERNEL_H__ */
